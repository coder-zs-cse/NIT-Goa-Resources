#include<iostream>
using namespace std;

class STRING{
    char *word;
    int len=0;
    public:
    STRING();
    STRING(const char*);
    STRING(const STRING&);
    STRING operator + (STRING);
    void display();
};
int main(){
    STRING s1 = "NIT";
    STRING s2 = "GOA";
    STRING s3 = s1 + s2;

    s1.display();
    s2.display();
    s3.display();

    return 0;
}
STRING::STRING(){
    word=new char[1];
    word[0]='\0';
}

STRING::STRING(const char *copy){
    int i=0;
    while(copy[i]!='\0'){
        i++;
    }
    len=i;
    word=new char[len+1];
    word[len] = '\0';
    for(int j=0;j<len;j++){
        word[j]=copy[j];
    }
}
STRING::STRING(const STRING &copy){
    len=copy.len;
    word = new char[len+1];
    word[len] = '\0';
    for(int i=0;i<len;i++){
        word[i]=copy.word[i];
    }
}
STRING STRING::operator + (STRING s){
    STRING output;
    output.len = len + s.len;
    output.word = new char[output.len +1];
    output.word[output.len] = '\0';
    int i=0;
    for(i;i<len;i++){
        output.word[i] = word[i];
    }
    for(int j=0;j<s.len;j++){
        output.word[i+j] = s.word[j];
    }
    return output;
}
void STRING::display(){
    cout<<word<<endl;
}