SELECT * FROM depositor;


