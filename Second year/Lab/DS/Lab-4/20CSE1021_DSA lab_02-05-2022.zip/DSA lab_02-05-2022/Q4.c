#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int type;  
#define STACKSIZE 100

typedef struct {
    int top;
    type array[STACKSIZE];
} stack;

stack *initialize() 
{
    stack *s = malloc(sizeof(stack));
    s->top = 0;
    return s;
}

void push(stack *s, type x) {
    assert(s->top < STACKSIZE);
    s->array[s->top++] = x;
}

type pop(stack *s) {
    assert(s->top > 0);
    return s->array[--s->top];
}

type isfull(stack *s) {
    return s->top >= STACKSIZE;
}

type isempty(stack *s) {
    return !s->top;
}

type peek(stack *s) {
    assert(s->top > 0);
    return s->array[s->top - 1];
}

void sortstack(stack *s) 
{ 
    stack *temp = initialize();
    int flag;
    do {
        flag = 0;
        while (!isempty(s)) {
            type x = pop(s);
            if (!isempty(s) && x > peek(s)) {
                push(temp, pop(s));
                push(s, x);
                flag = 1;
            } else {
                push(temp, x);
            }
        }
        while (!isempty(temp)) {
            push(s, pop(temp));
        }
    } while (flag);
}

int main() {
    stack *s = initialize();
    push(s, 2);
    push(s, 4);
    push(s, 4);
    push(s, 17);
    push(s, 9);
    push(s, 18);
    sortstack(s);
    while (!isempty(s)) {
        printf("%d  ", pop(s));
    }
    printf("\n");

    
    return 0;
}