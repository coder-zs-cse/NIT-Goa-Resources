#include<stdio.h>
#include<stdlib.h>

int rotate_array_one_position(int arr[],int n)
{
    int temp,temp2;
    int *a =(int*)malloc(sizeof(n));
    temp = arr[n-1];
    a[0] = temp;
    
    for(int i=0;i<n;i++)
    {
            temp2 = arr[i];
            a[i+1] = temp2;   
    }
    
    for(int i=0;i<n;i++)
    {
        arr[i] = a[i];    
    }

    printf("the array after rotation of one position is:");
    for(int i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }    
}

int main()
{
    int n;
    printf("enter the size of array");
    scanf("%d",&n);
    int *arr = (int*)malloc(sizeof(n));
    for(int i=0;i<n;i++)
    {
        printf("enter %dth element",i);
        scanf("%d",&arr[i]);
    }

    printf("the original array is:");
    for(int i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
    rotate_array_one_position(arr,n);

}
